﻿using System.Collections.Generic;
using Microsoft.EntityFrameworkCore;
using TixtlySW.Models;

namespace TixtlySW.Models
{
    public class TixtlydbContext : DbContext
    {
        public TixtlydbContext(DbContextOptions<TixtlydbContext> options)
            : base(options)
        {
        }

        public DbSet<Evento> Eventos { get; set; }
    }
}
