﻿namespace TixtlySW.Models
{
    public class sinRegistro
    {
        public List<Evento> eventoImportante { get; set; }
        public List<Evento> eventoProximo { get; set; }
    }
}
