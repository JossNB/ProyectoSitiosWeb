﻿using System;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace TixtlySW.Models
{
    [Table("Eventos", Schema = "dbo")] // Ajusta el esquema si fuera distinto
    public class Evento
    {
        [Key]
        [Column("EventoID")]
        public int EventoID { get; set; }

        [Column("LugarID")]
        public int LugarID { get; set; }

        [Column("Titulo")]
        public string Titulo { get; set; }

        [Column("Descripcion")]
        public string Descripcion { get; set; }

        [Column("FechaInicio")]
        public DateTime FechaInicio { get; set; }

        [Column("FechaFin")]
        public DateTime FechaFin { get; set; }

        [Column("Estado")]
        public string Estado { get; set; }

        [Column("horaInicio")]
        public string horaInicio { get; set; }

        [Column("horaFin")]
        public string horaFin { get; set; }

        [Column("CategoriaEvento")]
        public int CategoriaEvento { get; set; }

        [Column("Imagen")]
        public byte[] Imagen { get; set; }

    }
}
