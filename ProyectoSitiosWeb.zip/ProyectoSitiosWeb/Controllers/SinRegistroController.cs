﻿using Microsoft.AspNetCore.Mvc;
using TixtlySW.Models;
using System.Linq;
using Microsoft.EntityFrameworkCore; // Importante para usar .Include()

namespace TixtlySW.Controllers
{
    public class SinRegistroController : Controller
    {
        private readonly TixtlydbContext _context;

        public SinRegistroController(TixtlydbContext context)
        {
            _context = context;
        }

        public IActionResult InicioSinRegistro()
        {
            // 1. Eventos principales (por ejemplo, todos los eventos activos)
            var eventoImportante = _context.Eventos
                .Where(e => e.Estado == "Activo")
                .OrderBy(e => e.FechaInicio)
                .ToList();

            // 2. Eventos próximos (los que aún no han iniciado o están en curso)
            //    Filtramos por FechaInicio >= DateTime.Now, o FechaFin >= DateTime.Now, según tu definición de "actuales o próximos"
            var eventoProximo = _context.Eventos
                .Where(e => e.Estado == "Activo" && e.FechaFin >= DateTime.Now)
                .OrderBy(e => e.FechaInicio)
                .Take(3) // si quieres solo los 3 más próximos
                .ToList();

            // 3. Empaquetar en el ViewModel
            var viewModel = new sinRegistro
            {
                eventoImportante = eventoImportante,
                eventoProximo = eventoProximo
            };

            // 4. Pasar el ViewModel a la vista
            return View(viewModel);
        }

        public IActionResult BuscarEventos(string query)
        {
            if (string.IsNullOrEmpty(query))
            {
                // Retorna la vista con una lista vacía si la consulta está vacía
                return View("InicioSinRegistro", new List<Evento>());
            }

            // Intentar convertir la consulta a un número
            bool esNumero = int.TryParse(query, out int idBuscado);

            var eventos = _context.Eventos
                .Where(e => e.Estado == "Activo"
                    && (
                        e.Titulo.Contains(query)             // Coincidencia en Título
                        || e.Descripcion.Contains(query)     // Coincidencia en Descripción
                        || (esNumero && e.EventoID == idBuscado) // Coincidencia exacta en EventoID
                    )
                )
                .ToList();

            return View("InicioSinRegistro", eventos);
        }
        public IActionResult ResultadoBusqueda(string query)
        {
            // Si no hay término de búsqueda, retornamos todos los eventos activos
            if (string.IsNullOrEmpty(query))
            {
                var todos = _context.Eventos
                    .Where(e => e.Estado == "Activo")
                    .ToList();

                return View("ResultadoBusqueda", todos);
            }

            // Intentar convertir la consulta a un número para buscar por EventoID
            bool esNumero = int.TryParse(query, out int idBuscado);

            var queryMinuscula = query.ToLower();

            var eventos = _context.Eventos
                .Where(e => e.Estado == "Activo" &&
                    (
                        e.Titulo.ToLower().Contains(queryMinuscula)
                        || e.Descripcion.ToLower().Contains(queryMinuscula)
                        || (esNumero && e.EventoID == idBuscado)
                    )
                )
                .ToList();

            return View("ResultadoBusqueda", eventos);
        }

    }
}
