﻿using Microsoft.AspNetCore.Mvc;

namespace TixtlySW.Controllers
{
    public class CarritoController : Controller
    {
        public IActionResult Carrito()
        {
            return View();
        }
    }
}
