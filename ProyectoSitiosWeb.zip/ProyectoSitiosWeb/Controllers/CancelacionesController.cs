﻿using Microsoft.AspNetCore.Mvc;

namespace TixtlySW.Controllers
{
    public class CancelacionesController : Controller
    {
        public IActionResult Cancelaciones()
        {
            return View();
        }
    }
}
