﻿using Microsoft.AspNetCore.Mvc;

namespace TixtlySW.Controllers
{
    public class TiquetesReservasController : Controller
    {
        public IActionResult TiquetesReservas()
        {
            return View();
        }
    }
}
