﻿using Microsoft.AspNetCore.Mvc;

namespace TixtlySW.Controllers
{
    public class NotificacionesController : Controller
    {
        public IActionResult Notificaciones()
        {
            return View();
        }
    }
}
