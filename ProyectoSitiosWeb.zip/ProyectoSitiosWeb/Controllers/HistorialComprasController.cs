﻿using Microsoft.AspNetCore.Mvc;

namespace TixtlySW.Controllers
{
    public class HistorialComprasController : Controller
    {
        public IActionResult HistorialCompras()
        {
            return View();
        }
    }
}
